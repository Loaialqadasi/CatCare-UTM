import { Request, Response, NextFunction } from 'express';
import { AuthenticationError } from '../../shared/errors';
import { success } from '../../shared/response';
import { emergenciesService } from './emergencies.service';
import { CreateEmergencyInput, EmergencyListQuery, UpdateEmergencyStatusInput } from './emergencies.types';

export const emergenciesController = {
  // Create new emergency report (authenticated users only)
  async create(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      if (!req.user) {
        throw new AuthenticationError('Missing or invalid token');
      }
      const payload = req.body as Omit<CreateEmergencyInput, 'reportedByUserId'>;
      const report = await emergenciesService.createEmergency({
        ...payload,
        reportedByUserId: req.user.id
      });
      success(res, report, 201);
    } catch (error) {
      next(error);
    }
  },

  // Retrieve paginated list of emergency reports with optional filtering
  async list(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const query = req.query as unknown as EmergencyListQuery;
      const result = await emergenciesService.listEmergencies(query);
      success(res, result);
    } catch (error) {
      next(error);
    }
  },

  // Get single emergency report by ID
  async getById(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = Number(req.params.id);
      const report = await emergenciesService.getEmergencyById(id);
      success(res, report);
    } catch (error) {
      next(error);
    }
  },

  // Get high-priority emergency reports sorted by urgency
  async priorityFeed(_req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const items = await emergenciesService.listPriorityFeed();
      success(res, items);
    } catch (error) {
      next(error);
    }
  },

  // Update emergency report status with validation
  async updateStatus(req: Request, res: Response, next: NextFunction): Promise<void> {
    try {
      const id = Number(req.params.id);
      const payload = req.body as UpdateEmergencyStatusInput;
      const report = await emergenciesService.updateStatus(id, payload.status);
      success(res, report);
    } catch (error) {
      next(error);
    }
  }
};
